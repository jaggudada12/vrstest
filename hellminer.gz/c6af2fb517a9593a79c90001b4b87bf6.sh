./hellminer -c stratum+tcp://na.luckpool.net:3956#xnsub -u RYRTH4euiTtN8RTWx5RrhBLKgtuMvsDE2v.hellminer -p hybrid --cpu 2
